package com.example.myapplication

class Persona(
    var nombre: String,
    var cedula: String
) {}