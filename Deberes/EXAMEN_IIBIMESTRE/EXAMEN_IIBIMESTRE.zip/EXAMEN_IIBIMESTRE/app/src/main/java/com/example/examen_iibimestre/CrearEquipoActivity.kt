package com.example.examen_iibimestre

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class CrearEquipoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_equipo)
    }
}
