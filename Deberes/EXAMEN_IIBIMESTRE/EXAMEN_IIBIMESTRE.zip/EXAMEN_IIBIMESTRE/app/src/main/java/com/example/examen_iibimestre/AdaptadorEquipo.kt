package com.example.examen_iibimestre

class AdaptadorEquipo {
}