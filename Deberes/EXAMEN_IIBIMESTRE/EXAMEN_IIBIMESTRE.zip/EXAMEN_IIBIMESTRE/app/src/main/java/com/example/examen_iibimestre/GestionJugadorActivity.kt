package com.example.examen_iibimestre

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class GestionJugadorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gestion_jugador)
    }
}
